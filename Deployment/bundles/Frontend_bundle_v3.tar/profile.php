<?php
session_start();

//REDIRECT TO LOGIN IF NOT LOGGED IN PROPERLY (so you can't access without signing in hehe)
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: index.php");
    exit();
}

//functions and headers
require_once 'includes/data.php';
require_once 'includes/header.php';

$msg = '';
$tab = $_GET['tab'] ?? 'books';


//ALL OF THIS MUST MATCH NAT'S BACKEND CODE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $result = rmq_rpc('user.update', [
        'display_name' => trim($_POST['display_name'] ?? ''), 
        'email'=> trim($_POST['email'] ?? ''),
        'bio'=> trim($_POST['bio'] ?? ''),
        'preferences' => $_POST['prefs'] ?? [],
    ]);
    $msg = ($result['success'] ?? false)
        ? 'Profile updated.'
        : 'Could not save changes. Please try again.';
}

//loading user data for display

$profile = rmq_rpc('user.profile') ?? [];
$stats = $profile['stats'] ?? [];
$genre_count = $profile['genre_affinity'] ?? [];
arsort($genre_count);


$userRatings = [];
if ($tab === 'books') {
    $ratings = rmq_rpc('user.ratings') ?? [];
    $userRatings  = $ratings['ratings'] ?? [];
}

$userReviews = [];
if ($tab === 'reviews') {
    $reviews = rmq_rpc('user.reviews') ?? [];
    $userReviews  = $reviews['reviews'] ?? [];
}

$userSettings = [];
if ($tab === 'settings') {
    $settings  = rmq_rpc('user.settings') ?? [];
    $userSettings = $settings ?? [];
}
$savedPreferences = $userSettings['preferences'] ?? [];

?>


<!--HTML CODE-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Noetic — Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=IM+Fell+English:ital@0;1&family=Crimson+Text:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
    <?php if ($msg): ?>
    <div class="n-alert mb-3"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

<div class="row g-4">
    <div class="col-lg-8">

<!--profile header with avatar information, image bio etc-->
        <div class="profile-header">
            <div class="profile-banner"></div>
            <div class="n-card p-4 pt-0 profile-banner-border">
                <div class="profile-avatar">
                    <?php if (!empty($profile_res['avatar_url'])): ?>
                        <img src="<?php echo htmlspecialchars($profile_res['avatar_url']); ?>" alt="">
                    <?php else: ?>
                        <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                    <?php endif; ?>
                </div>
                <div class="profile-header-content">
                    <div>
                        <h3 class="profile-name">
                            <?php echo htmlspecialchars($profile_res['display_name'] ?? $_SESSION['username']); ?>
                        </h3>
                        <div class="profile-meta">
                            @<?php echo htmlspecialchars($_SESSION['username']); ?>
                            &nbsp;·&nbsp; Member since <?php echo $profile_res['member_since'] ?? '—'; ?>
                        </div>
                        <?php if (!empty($profile_res['bio'])): ?>
                        <div class="profile-bio">
                            <?php echo htmlspecialchars($profile_res['bio']); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <a href="logout.php"
                       class="logout-btn">
                        <i class="bi bi-box-arrow-right"></i> Log Out
                    </a>
                </div>
            </div>
        </div>

        <div class="tab-nav">
            <a href="?tab=books" class="tab-link-profile <?php echo $tab === 'books' ? 'active':''; ?>">Rated Books</a>
            <a href="?tab=reviews" class="tab-link-profile <?php echo $tab === 'reviews' ? 'active':''; ?>">Reviews</a>
            <a href="?tab=circles" class="tab-link-profile <?php echo $tab === 'circles' ? 'active':''; ?>">Circles</a>
            <a href="?tab=settings" class="tab-link-profile <?php echo $tab === 'settings' ? 'active':''; ?>">Settings</a>
        </div>

 <!--books tab of the profile page-->
        <?php if ($tab === 'books'): ?>

        <?php if (empty($my_ratings)): ?>
        <p class="empty-msg">
            No books rated yet. <a href="books.php" style="color:var(--umber);">Browse the library.</a>
        </p>
        <?php else: ?>
            <?php foreach ($my_ratings as $entry):
                $b = $entry['book'] ?? [];
                $rating = $entry['rating'] ?? 0;
            ?>
            <div class="rated-book">
                <a href="books.php?id=<?php echo $b['id']; ?>">
                    <img src="<?php echo htmlspecialchars($b['cover']); ?>" class="rated-book-cover"alt="">
                </a>
                <div class="flex-grow-1">
                    <a href="books.php?id=<?php echo $b['id']; ?>"
                       class="rated-book-title">
                        <?php echo htmlspecialchars($b['title']); ?>
                    </a>
                    <div class="rated-book-author"><?php echo htmlspecialchars($b['author']); ?></div>
                </div>
                <div><?php echo renderStars($rating); ?></div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>

<!--reviews tab for reviewing books-->
        <?php elseif ($tab === 'reviews'): ?>

        <?php if (empty($my_reviews)): ?>
        <p class="empty-msg">No reviews written yet.</p>
        <?php else: ?>
            <?php foreach ($my_reviews as $rv):
                $rvb = $rv['book'] ?? [];
            ?>
            <div class="review-entry">
                <div class="d-flex gap-3 align-items-start">
                    <img src="<?php echo htmlspecialchars($rvb['cover'] ?? ''); ?>"
                         class="review-cover" alt="">
                    <div>
                        <div class="review-meta">
                            <a href="books.php?id=<?php echo $rvb['id']; ?>"
                               style="review-book-link">
                                <?php echo htmlspecialchars($rvb['title'] ?? ''); ?>
                            </a>
                            &nbsp;·&nbsp; <?php echo $rv['created']; ?>
                        </div>
                        <?php echo renderStars($rv['rating']); ?>
                        <div class="review-title">
                            "<?php echo htmlspecialchars($rv['title']); ?>"
                        </div>
                        <p class="review-body">
                            <?php echo htmlspecialchars($rv['body']); ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!--circles tab, this shows where the user is involved in within the app itself-->
        <?php elseif ($tab === 'circles'): ?>

        <div class="row g-3">
            <?php foreach ($my_groups as $g):
                $cb = getBookById((int)$g['current_book_id']);
            ?>
            <div class="col-md-6">
                <a href="groups.php?id=<?php echo $g['id']; ?>" class="text-decoration-none">
                    <div class="n-card p-3 d-flex gap-3 align-items-start"
                         style="transition:border-color 0.2s;"
                         onmouseover="this.style.borderColor='rgba(134,113,91,0.5)'"
                         onmouseout="this.style.borderColor='rgba(134,113,91,0.2)'">
                        <?php if ($cb): ?>
                        <img src="<?php echo htmlspecialchars($cb['cover']); ?>"
                             style="width:40px;height:60px;object-fit:cover;border:1px solid rgba(134,113,91,0.3);border-radius:1px;flex-shrink:0;" alt="">
                        <?php endif; ?>
                        <div>
                            <div style="font-family:'Cormorant Garamond',serif; font-size:1.05rem; color:var(--blush);">
                                <?php echo htmlspecialchars($g['name']); ?>
                            </div>
                            <?php if ($cb): ?>
                            <div style="font-size:0.8rem; color:var(--text-muted); font-style:italic;"><?php echo htmlspecialchars($cb['title']); ?></div>
                            <?php endif; ?>
                            <div style="font-size:0.75rem; color:var(--text-muted);"><?php echo $g['member_count']; ?> members</div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
            <?php if (empty($my_groups)): ?>
            <div class="col-12">
                <p style="color:var(--text-muted); font-style:italic;">
                    Not a member of any circles yet.
                    <a href="groups.php" style="color:var(--umber);">Find one to join.</a>
                </p>
            </div>
            <?php endif; ?>
        </div>

        <?php elseif ($tab === 'settings'): ?>

        <div class="n-card p-4">
            <h5 style="font-family:'IM Fell English',serif; margin-bottom:1.2rem;">Profile Settings</h5>
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Display Name</label>
                    <input type="text" class="form-control" name="display_name"
                           value="<?php echo htmlspecialchars($user_settings['display_name'] ?? $_SESSION['username']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email"
                           value="<?php echo htmlspecialchars($user_settings['email'] ?? ''); ?>"
                           placeholder="your@email.com">
                </div>
                <div class="mb-3">
                    <label class="form-label">Reading Preferences</label>
                    <div class="d-flex flex-wrap gap-2 mt-1">
                        <?php foreach ($genres as $g): ?>
                        <label style="cursor:pointer;">
                            <input type="checkbox" name="prefs[]" value="<?php echo htmlspecialchars($g); ?>"
                                   <?php echo in_array($g, $saved_prefs) ? 'checked' : ''; ?>
                                   style="display:none;"
                                   onchange="this.nextElementSibling.style.borderColor = this.checked ? 'var(--umber)' : '';
                                             this.nextElementSibling.style.color = this.checked ? 'var(--blush)' : '';">
                            <span class="n-badge" style="cursor:pointer;
                                  <?php echo in_array($g, $saved_prefs) ? 'border-color:var(--umber);color:var(--blush);' : ''; ?>">
                                <?php echo htmlspecialchars($g); ?>
                            </span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Bio</label>
                    <textarea class="form-control" rows="3" name="bio"
                              placeholder="A few words about your reading life…"><?php echo htmlspecialchars($user_settings['bio'] ?? ''); ?></textarea>
                </div>
                <button type="submit" class="btn-n btn">Save Changes</button>
            </form>
        </div>

        <?php endif; ?>
    </div>

    <div class="col-lg-4">
        <div class="n-card p-4 mb-4">
            <h6 style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.12em; color:var(--text-muted); margin-bottom:1.2rem;">Reading Statistics</h6>
            <div class="row g-3 text-center">
                <div class="col-6">
                    <div style="font-family:'IM Fell English',serif; font-size:2rem; line-height:1;"><?php echo $stats['books_rated'] ?? 0; ?></div>
                    <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted);">Books Rated</div>
                </div>
                <div class="col-6">
                    <div style="font-family:'IM Fell English',serif; font-size:2rem; line-height:1;"><?php echo $stats['reviews_written'] ?? 0; ?></div>
                    <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted);">Reviews</div>
                </div>
                <div class="col-6">
                    <div style="font-family:'IM Fell English',serif; font-size:2rem; line-height:1;"><?php echo $stats['avg_rating'] ?? '—'; ?></div>
                    <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted);">Avg Rating</div>
                </div>
                <div class="col-6">
                    <div style="font-family:'IM Fell English',serif; font-size:2rem; line-height:1;"><?php echo number_format($stats['pages_read'] ?? 0); ?></div>
                    <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted);">Pages Read</div>
                </div>
            </div>
        </div>

        <?php if (!empty($genre_count)): ?>
        <div class="n-card p-4 mb-4">
            <h6 style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.12em; color:var(--text-muted); margin-bottom:1rem;">Genre Affinities</h6>
            <?php
            $max_gc = max($genre_count) ?: 1;
            foreach (array_slice($genre_count, 0, 5, true) as $genre => $count):
            ?>
            <div style="margin-bottom:0.6rem;">
                <div style="display:flex; justify-content:space-between; font-size:0.85rem;">
                    <span><?php echo htmlspecialchars($genre); ?></span>
                    <span style="color:var(--text-muted);"><?php echo $count; ?></span>
                </div>
                <div style="height:3px; background:rgba(134,113,91,0.2); border-radius:2px; margin-top:3px;">
                    <div style="height:100%; width:<?php echo round(($count / $max_gc) * 100); ?>%; background:linear-gradient(90deg,var(--umber),#c9a87c); border-radius:2px;"></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="n-card p-4">
            <h6 style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.12em; color:var(--text-muted); margin-bottom:0.8rem;">My Circles</h6>
            <?php foreach ($my_groups as $g): ?>
            <a href="groups.php?id=<?php echo $g['id']; ?>"
               style="display:flex; align-items:center; gap:0.5rem; text-decoration:none; margin-bottom:0.5rem;">
                <div class="avatar-ring" style="width:28px;height:28px;font-size:0.7rem;">
                    <?php echo strtoupper(substr($g['name'], 0, 1)); ?>
                </div>
                <span style="font-size:0.9rem; color:var(--text-muted); transition:color 0.2s;"
                      onmouseover="this.style.color='var(--blush)'"
                      onmouseout="this.style.color='var(--text-muted)'">
                    <?php echo htmlspecialchars($g['name']); ?>
                </span>
            </a>
            <?php endforeach; ?>
            <?php if (empty($my_groups)): ?>
            <p style="font-size:0.85rem; color:var(--text-muted); font-style:italic;">No circles yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
</html>

<!--footer code :) at least it stays consistent-->
<?php require_once 'includes/footer.php'; ?>